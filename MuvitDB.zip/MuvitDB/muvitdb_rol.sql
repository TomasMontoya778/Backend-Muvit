-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: muvitdb
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rol`
--

DROP TABLE IF EXISTS `rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rol` (
  `id_rol` bigint(20) NOT NULL AUTO_INCREMENT,
  `name_user` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol_enum` enum('Driver','User','Admin') DEFAULT NULL,
  `user_photo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol`
--

LOCK TABLES `rol` WRITE;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` VALUES (1,'tomas1213@','@tomas1213.','User','https://res.cloudinary.com/dis8xzifs/image/upload/v1716313610/muvitUserProfiles/Screenshot_2024-05-20_094131_iceotg.png'),(3,'SamuelChamu@','@samuelChamu1213@.','Driver','https://res.cloudinary.com/dis8xzifs/image/upload/v1716259230/muvitUserProfiles/Screenshot_2024-05-20_094423_pbqqyo.png'),(4,'Elizabeth Beltrán','@Eliza04Beltran20@.','User','https://placehold.co/200x200/EEE/31343C?font=oswald&text=EB'),(6,'HernánDavid10','@davidAlvare01@.','User','https://placehold.co/200x200/EEE/31343C?font=oswald&text=HD'),(8,'SamuelElChimuel','@chimuelSamuelR13@.','Driver','https://placehold.co/200x200/EEE/31343C?font=oswald&text=SR'),(9,'Pedro123','@Pedro123','User','https://res.cloudinary.com/dis8xzifs/image/upload/v1716314194/muvitUserProfiles/Screenshot_2024-05-13_153633_p279m9.png'),(10,'hernan1772','$2a$10$cdvo/ZwneAOzCJ0S5XOL8.s28.gBM4B8MULeO9Bzp8XcvzGzfrXXK','Driver',NULL);
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-22 13:39:08
