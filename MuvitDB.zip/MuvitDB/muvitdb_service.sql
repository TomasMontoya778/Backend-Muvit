-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: muvitdb
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service` (
  `id_service` varchar(255) NOT NULL,
  `assistant` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `distance` varchar(255) NOT NULL,
  `final_point` varchar(255) NOT NULL,
  `payment` tinyint(4) NOT NULL,
  `price` double NOT NULL,
  `size` enum('SMALL','MEDIUM','XL') NOT NULL,
  `start_point` varchar(255) NOT NULL,
  `status_service` enum('ACTIVE','INACTIVE','PENDING','AVAILABLE') NOT NULL,
  `time` time(6) NOT NULL,
  `type_service` enum('BASIC','PREMIUN') NOT NULL,
  `id_driver` varchar(255) DEFAULT NULL,
  `id_user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_service`),
  KEY `FKruoam0w4kb1h4bofphfek181a` (`id_driver`),
  KEY `FKpwoau2ra6no3c7dkh7ybt6vu4` (`id_user`),
  CONSTRAINT `FKpwoau2ra6no3c7dkh7ybt6vu4` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`),
  CONSTRAINT `FKruoam0w4kb1h4bofphfek181a` FOREIGN KEY (`id_driver`) REFERENCES `driver` (`id_driver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES ('079452c6-2e23-463d-9baa-2027c87d838d',5,'2024-05-21','50 KM','Cordoba',0,55.5,'XL','Barbosa','AVAILABLE','15:50:00.000000','PREMIUN',NULL,'1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('123d1a73-2643-404c-a7b7-6c9bcaba106a',2,'2024-04-09','35 KM','Envigado',2,38.89,'XL','Bello','INACTIVE','11:00:00.000000','BASIC','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('2597783b-261c-491c-b7b4-709a8af1eb1b',5,'2024-05-30','40 KM','Caldas',2,40.99,'XL','Sabaneta','AVAILABLE','10:30:00.000000','PREMIUN',NULL,'1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('489dfd63-2114-493a-b034-4fc80b11dd47',3,'2024-05-30','21 KM','Envigado',2,25.77,'XL','Robledo','AVAILABLE','13:30:00.000000','PREMIUN','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('496114fe-91f6-40c3-af39-49ad04b149d4',5,'2024-05-30','40 KM','Caldas',2,40.99,'XL','Sabaneta','AVAILABLE','10:30:00.000000','PREMIUN','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('59fdddcb-4d0b-461f-9f57-0da3074b13ef',5,'2024-05-21','19 KM','Cordoba',0,20.5,'XL','Santander','AVAILABLE','15:50:00.000000','PREMIUN','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('7b5897a8-389d-4108-adca-500fa0cab5c5',5,'2024-05-30','50 KM','Cordoba',0,55.5,'XL','Barbosa','PENDING','15:50:00.000000','PREMIUN','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('7cc698ac-c5fe-4136-a4eb-f8957d35d08b',6,'2024-05-01','40 KM','Alto de palmas',2,45.1,'XL','Copacabana','INACTIVE','08:00:00.000000','PREMIUN','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('7e9909b5-73ad-4160-abda-47aa4f97907f',5,'2024-05-30','40 KM','Caldas',2,40.99,'XL','Sabaneta','ACTIVE','10:30:00.000000','PREMIUN','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('90727f8e-075d-43ca-85ce-4dad16db1efa',5,'2024-06-02','10 KM','Castilla',0,22.5,'XL','Robledo','PENDING','19:10:00.000000','BASIC','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('919a40c0-aef6-41e1-87b7-dfaa271e426a',5,'2024-06-04','40 KM','Unidad Residencial Los Colores',2,43.5,'XL','CRA 80 #79 B 31','PENDING','19:10:00.000000','PREMIUN','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('980df02d-5076-4d4c-b8b7-0c41fc663b48',5,'2024-05-21','19 KM','Cordoba',0,20.5,'MEDIUM','Santander','PENDING','15:50:00.000000','PREMIUN','5368f59b-010f-4208-9c13-879f5a7e375c','5dd814bc-927f-4ac2-a238-d294c5e51923'),('ac2270a4-99bd-497a-9667-f59a88216273',5,'2024-05-21','19 KM','Cordoba',0,20.5,'MEDIUM','Santander','PENDING','15:50:00.000000','PREMIUN','5368f59b-010f-4208-9c13-879f5a7e375c','5dd814bc-927f-4ac2-a238-d294c5e51923'),('bbddcc4e-9252-4d90-95ae-0f7ca4bf0bb9',5,'2024-06-07','10 KM','Unidad Residencial Los Milagros',2,13.5,'XL','CRA 57 #102 C','PENDING','10:20:00.000000','PREMIUN','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('cb555c74-edc9-462a-b962-f696681303ba',1,'2024-01-23','10 KM','Los Colores',0,14.99,'SMALL','Robledo','INACTIVE','13:30:00.000000','BASIC','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599'),('ec974b1b-2a68-459a-853f-f71098b77099',5,'2024-05-21','19 KM','Cordoba',0,20.5,'MEDIUM','Santander','AVAILABLE','15:50:00.000000','PREMIUN','5368f59b-010f-4208-9c13-879f5a7e375c','5dd814bc-927f-4ac2-a238-d294c5e51923'),('ed05c54f-e3c7-464a-8cb3-f42dc59757e5',2,'2024-03-10','20 KM','Robledo',0,23.1,'MEDIUM','Bello','INACTIVE','15:10:00.000000','BASIC','b6a74702-211e-4717-8fbf-08e122d5fe98','1f6fc3f0-f8f9-438b-81c8-66401b7f5599');
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-22 13:39:08
